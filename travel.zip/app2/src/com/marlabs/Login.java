////package com.marlabs;
////import java.sql.*;  
////
////public final class Login {
////
////	public static void main(String[] args) {
////		 
////		try{  
////		Class.forName("com.mysql.jdbc.Driver");  
////		Connection con=DriverManager.getConnection(  
////		"jdbc:mysql://localhost:3306/sonoo","root","marlabs");  
////		System.out.println("hii");
////		
////		//here sonoo is database name, root is username and password  
////		
////		Statement stmt=con.createStatement();  
////		ResultSet rs=stmt.executeQuery("select * from user");  
////	while(rs.next())  
////	System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
////		con.close();  
////		}catch(Exception e){ System.out.println(e);}  
////		}  
////	
////
////	}
////
//
//package com.marlabs;
////import java.sql.*;  
////
////public final class Login {
////
////public static void main(String[] args) {
////	String myDriver = "com.mysql.jdbc.Driver";
////	String myUrl = "jdbc:mysql://localhost:3306/sonoo" ;
////	Class.forName(myDriver);
////	Connection conn = DriverManager.getConnection(myUrl, "root", "marlabs");
////	
////	String query = "insert into users(id, username, password)" + "values(?, ? , ?)";
////	
////	PreparedStatement preparedStmt = conn.prepareStatement(query);
////	preparedStmt.setInt(1, 1);
////	preparedStmt.setString(2, "pritesh");
////	preparedStmt.setString(3, "prit");
////	
////	preparedStmt.execute();
////	
////	conn.close();
////}
////catch(Exception e)
////{
////	System.err.println("got an exception");
////	
////	
////	
////}
//import java.sql.*;
//import java.util.Calendar;
//
//public class Login{
//
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	
//		/**
//		 * A Java MySQL PreparedStatement INSERT example.
//		 * Demonstrates the use of a SQL INSERT statement against a
//		 * MySQL database, called from a Java program, using a
//		 * Java PreparedStatement.
//		 * 
//		 * Created by Alvin Alexander, http://alvinalexander.com
//		 */
//		
//		    try
//		    {
//		      // create a mysql database connection
//		      String myDriver = "com.mysql.jdbc.Driver";
//		      String myUrl = "jdbc:mysql://localhost:3306/bhavani";
//		      Class.forName(myDriver);
//		      Connection conn = DriverManager.getConnection(myUrl, "root", "marlabs");
//		    
//		    /*  // create a sql date object so we can use it in our INSERT statement
//		      Calendar calendar = Calendar.getInstance();
//		      java.sql.Date startDate = new java.sql.Date(calendar.getTime().getTime());*/
//
//		      // the mysql insert statement
//		      String query = " insert into detail (username,password)"
//		        + " values (?, ?)";
//
//		      // create the mysql insert preparedstatuserement
//		      PreparedStatement preparedStmt = conn.prepareStatement(query);
//		      preparedStmt.setString (1, "katty");
//		      preparedStmt.setString (2, "Ru");
//		     
//
//		      // execute the preparedstatement
//		      preparedStmt.execute();
//		      System.out.println("success");
//		      conn.close();
//		    }
//		    catch (Exception e)
//		    {
//		      System.err.println("Got an exception!");
//		      System.err.println(e.getMessage());
//	}
//	}
//}
//
//
//		 
////		try{  