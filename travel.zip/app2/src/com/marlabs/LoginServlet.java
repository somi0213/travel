package com.marlabs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {  
	
	Connection con =null;
		
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String un=request.getParameter("username");
			String pw=request.getParameter("password");
			
			// Connect to mysql and verify username password
			
			try {
				
			 // loads driver
				 con = DatabaseConnection.initializeDatabase();
	 
			PreparedStatement ps = con.prepareStatement("select username,password from detail where username=? and password=?");
			ps.setString(1, un);
			ps.setString(2, pw);
	 
			ResultSet rs = ps.executeQuery();
	 
			while (rs.next()) {
				response.sendRedirect("place_list.html");
				return;
			}
			response.sendRedirect("error.html");
			return;
			} catch(Exception ex)
			{
				ex.printStackTrace();
				System.out.println("exception");
				
			}
		}

	}

	
/*public void doPost(HttpServletRequest request, HttpServletResponse response)  
        throws ServletException, IOException {  
	//public static boolean validate(String username,String password){  
		boolean status=false;  
		Connection con =null;
		String username = null;

		try{  
		
		 * Class.forName("com.mysql.jdbc.Driver"); con=DriverManager.getConnection(
		 * "jdbc:mysql://localhost/bhavani","root","marlabs");
		 
			
		PreparedStatement ps=con.prepareStatement(  
		"select * from detail where username=? and password=?");  
		
		ps.setString(1,username);  
		String password = null;
		ps.setString(2,password);  
		      
		ResultSet rs=ps.executeQuery();  
		status=rs.next();  
		          
		}catch(Exception e){System.out.println(e);}  
		return;  
		

}
    response.setContentType("text/html");  
    PrintWriter out = response.getWriter();  
          
    String n=request.getParameter("username");  
    String p=request.getParameter("password");  
          
//    if(LoginDao.validate(n, p)){  
//        RequestDispatcher rd=request.getRequestDispatcher("travel");  
//        rd.forward(request,response);  
//    }  
//    else{  
//        out.print("Sorry username or password error");  
//        RequestDispatcher rd=request.getRequestDispatcher("login.html");  
//        rd.include(request,response);  
//    }  
          
  //  out.close();  
    
}  */